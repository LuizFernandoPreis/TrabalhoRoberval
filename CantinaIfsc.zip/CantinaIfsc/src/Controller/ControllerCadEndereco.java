
package Controller;


import Model.bo.Bairro;
import Model.bo.Cidade;
import Model.bo.Endereco;
import View.TelaCadastroBairro;
import View.TelaCadastroCidade;
import View.TelaCadastroEndereco;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class ControllerCadEndereco implements ActionListener{
    TelaCadastroEndereco telaCadastroEndereco;
    view.TelaBuscaEndereco telaBusca;
    ControllerBuscaEndereco controller;
    public ControllerCadEndereco(TelaCadastroEndereco telaCadastroEndereco) {
        this.telaBusca = new view.TelaBuscaEndereco(null,true);
        this.controller = new ControllerBuscaEndereco(telaBusca,this);
        this.telaCadastroEndereco = telaCadastroEndereco;
        this.telaCadastroEndereco.getCancelar().addActionListener(this);
        this.telaCadastroEndereco.getBuscar().addActionListener(this);
        this.telaCadastroEndereco.getNovo().addActionListener(this);
        this.telaCadastroEndereco.getGravar().addActionListener(this);
        this.telaCadastroEndereco.getSair().addActionListener(this);
        Controller.utilities.Utilities.ativa(true, this.telaCadastroEndereco.getBody());
        this.telaCadastroEndereco.getIdTexto().setText(Integer.toString(DAO.ClasseDados.listaEndereco.size() + 1));
        this.telaCadastroEndereco.getIdTexto().setEnabled(false);
        
    }
    
   
   
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.telaCadastroEndereco.getCancelar()){
            Controller.utilities.Utilities.ativa(true, this.telaCadastroEndereco.getBody());
            Controller.utilities.Utilities.limpaComponentes(true, this.telaCadastroEndereco.getBody());
        } else if(e.getSource() == this.telaCadastroEndereco.getNovo()){
            Controller.utilities.Utilities.ativa(false, this.telaCadastroEndereco.getBody());
        }else if(e.getSource() == this.telaCadastroEndereco.getGravar()){
            String on = "";
            if(this.telaCadastroEndereco.getStatus().isSelected() == true){
                on = "a";
            }else if(this.telaCadastroEndereco.getStatus().isSelected() == false){
                on = "d";
            }
            Bairro bairro = new Bairro();
           
            Cidade cidade = new Cidade();
            if(Integer.parseInt(this.telaCadastroEndereco.getIdTexto().getText()) > DAO.ClasseDados.listaEndereco.size()){
                Endereco endereco = new Endereco(DAO.ClasseDados.listaEndereco.size() + 1,this.telaCadastroEndereco.getCepTexto().getText(), this.telaCadastroEndereco.getLogradouroTexto().getText(), on, bairro, cidade);
                DAO.ClasseDados.listaEndereco.add(endereco);
                Controller.utilities.Utilities.ativa(true, this.telaCadastroEndereco.getBody());
                Controller.utilities.Utilities.limpaComponentes(true, this.telaCadastroEndereco.getBody());
                this.telaCadastroEndereco.getIdTexto().setText( Integer.toString(DAO.ClasseDados.listaEndereco.size() + 1));
            }else if(DAO.ClasseDados.listaEndereco.contains(DAO.ClasseDados.listaEndereco.get(Integer.parseInt(this.telaCadastroEndereco.getIdTexto().getText())-1))){
                Endereco endereco =  DAO.ClasseDados.listaEndereco.get(Integer.parseInt(this.telaCadastroEndereco.getIdTexto().getText()) - 1);
                endereco.setCep(this.telaCadastroEndereco.getCepTexto().getText());
                endereco.setLogradoura(this.telaCadastroEndereco.getLogradouroTexto().getText());
                endereco.setStatus(on);
                endereco.setBairro(bairro);
                Controller.utilities.Utilities.ativa(true, this.telaCadastroEndereco.getBody());
                Controller.utilities.Utilities.limpaComponentes(true, this.telaCadastroEndereco.getBody());
                this.telaCadastroEndereco.getIdTexto().setText( Integer.toString(DAO.ClasseDados.listaEndereco.size() + 1));
            }
            
            
            
            
            
            
            
            
            
            
        }else if(e.getSource() == this.telaCadastroEndereco.getBuscar()){
            telaBusca.setVisible(true);
        }
    }}
